<?php
include_once "../../../funciones/funciones.php";
protegerPagina([0, 3]);

// BORRAR
if (isset($_GET['borrar'])) {
    borrarViaje((int)$_GET['borrar']);
    header("Location: lista_viajes.php");
    exit;
}

$viajes = obtenerViajes();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Listado de Viajes</title>

    <link rel="stylesheet" href="../../../css/estilos.css">
    <link rel="stylesheet" href="../../../css/listado_viajes.css">

    <style>
        /* CONTENEDOR */
        .container {
            width: 100%;
            margin: 0 auto;
        }

        /* MENU SUPERIOR */
        .menu-viajes {
            display: flex;
            gap: 10px;
            width: 100%;
            margin-bottom: 20px;
        }

        .menu-viajes a {
            flex: 1;
            text-align: center;
            padding: 5px 8px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            font-size: 13px;
        }

        .menu-viajes a:hover {
            background: #0056b3;
        }

        /* SCROLL TABLA */
        .tabla-scroll {
            max-height: 500px;
            overflow-y: auto;
            border: 1px solid #ccc;
        }

        /* TABLA */
        .table {
            width: 100%;
            table-layout: auto;
            border-collapse: collapse;
        }

        .table td,
        .table th {
            white-space: normal;
            word-break: break-word;
            padding: 4px 8px;
            vertical-align: top;
        }

        .table td {
            max-width: 250px;
        }

        .table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        /* HEADER FIJO */
        .table thead th {
            position: sticky;
            top: 0;
            background: #343a40;
            color: white;
            z-index: 3;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="card">

            <h3>Estado de los Viajes</h3>

            <div class="menu-viajes">
                <a href="carga_viajes.php">+ Nuevo Viaje</a>
                <a href="">Pendientes</a>
                <a href="">Asignados</a>
                <a href="">En curso</a>
                <a href="">Diferidos</a>
                <a href="">Completados</a>
                <a href="">Cancelados</a>
            </div>

            <div class="tabla-scroll">
                <table class="table">
                    <thead>
                        <tr>
                            <th>N° viaje</th>
                            <th>Pasajero</th>
                            <th>Origen</th>
                            <th>Destino</th>
                            <th>Observaciones</th>
                            <th>Tipo</th>
                            <th>Fecha</th>
                            <th>Hora</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($viajes as $v): ?>
                            <tr style="<?= $v['diferido'] == "Si" ? 'background:#d4edda;' : '' ?>">

                                <td><?= $v['id'] ?></td>

                                <td>
                                    <?= $v['nombre_pasaj'] ?><br>
                                    <small><?= $v['cel_pasaj'] ?></small>
                                </td>

                                <td><?= $v['direccion_origen'] ?></td>
                                <td><?= $v['direccion_destino'] ?></td>

                                <td><?= $v['obs_operador'] ?></td>

                                <!-- TIPO -->
                                <td>
                                    <?= (empty($v['fecha']) || $v['fecha'] === '0000-00-00')
                                        ? 'Inmediato'
                                        : 'Diferido' ?>
                                </td>

                                <!-- FECHA -->
                                <td>
                                    <?= ($v['fecha'] === '0000-00-00' && empty($v['hora']))
                                        ? ''
                                        : $v['fecha'] ?>
                                </td>

                                <!-- HORA -->
                                <td>
                                    <?= ($v['fecha'] === '0000-00-00' && empty($v['hora']))
                                        ? ''
                                        : $v['hora'] ?>
                                </td>

                                <td>
                                    <a href="carga_viajes.php?editar=<?= $v['id'] ?>">Editar</a> |
                                    <a href="?borrar=<?= $v['id'] ?>" onclick="return confirm('¿Eliminar?')">Borrar</a>
                                </td>

                            </tr>
                        <?php endforeach; ?>
                    </tbody>

                </table>
            </div>

        </div>
    </div>

</body>

</html>